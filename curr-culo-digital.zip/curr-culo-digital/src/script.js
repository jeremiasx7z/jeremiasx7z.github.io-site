// ===== MAIN APPLICATION CONTROLLER =====
class CurriculumApp {
  constructor() {
    this.init()
  }

  init() {
    this.setupEventListeners()
    this.initializeAnimations()
    this.setupNavigation()
    this.animateSkillBars()
    this.animateCounters()
    this.setupScrollEffects()
  }

  // ===== EVENT LISTENERS SETUP =====
  setupEventListeners() {
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener("click", (e) => {
        e.preventDefault()
        const target = document.querySelector(anchor.getAttribute("href"))
        if (target) {
          target.scrollIntoView({
            behavior: "smooth",
            block: "start",
          })
        }
      })
    })

    // Profile image hover effect
    const profileImg = document.getElementById("profile-img")
    if (profileImg) {
      profileImg.addEventListener("mouseenter", () => {
        profileImg.style.transform = "scale(1.1) rotate(5deg)"
      })

      profileImg.addEventListener("mouseleave", () => {
        profileImg.style.transform = "scale(1) rotate(0deg)"
      })
    }

    // Contact items click to copy
    document.querySelectorAll(".contact-item").forEach((item) => {
      item.addEventListener("click", () => {
        const text = item.querySelector("span:last-child").textContent
        this.copyToClipboard(text)
        this.showNotification("Copiado para a área de transferência!")
      })
    })

    // Project cards interaction
    document.querySelectorAll(".project-card").forEach((card) => {
      card.addEventListener("mouseenter", () => {
        card.style.transform = "translateY(-15px) scale(1.02)"
      })

      card.addEventListener("mouseleave", () => {
        card.style.transform = "translateY(0) scale(1)"
      })
    })
  }

  // ===== NAVIGATION CONTROLLER =====
  setupNavigation() {
    const navbar = document.getElementById("navbar")
    const navLinks = document.querySelectorAll(".nav-link")
    let lastScrollTop = 0

    // Show/hide navbar on scroll
    window.addEventListener("scroll", () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop

      if (scrollTop > 100) {
        navbar.classList.add("visible")
      } else {
        navbar.classList.remove("visible")
      }

      // Update active navigation link
      this.updateActiveNavLink()

      lastScrollTop = scrollTop
    })

    // Initial active link setup
    this.updateActiveNavLink()
  }

  updateActiveNavLink() {
    const sections = document.querySelectorAll(".section, .hero-section")
    const navLinks = document.querySelectorAll(".nav-link")

    let currentSection = ""

    sections.forEach((section) => {
      const sectionTop = section.offsetTop - 100
      const sectionHeight = section.offsetHeight

      if (window.pageYOffset >= sectionTop && window.pageYOffset < sectionTop + sectionHeight) {
        currentSection = section.getAttribute("id")
      }
    })

    navLinks.forEach((link) => {
      link.classList.remove("active")
      if (link.getAttribute("href") === `#${currentSection}`) {
        link.classList.add("active")
      }
    })
  }

  // ===== SCROLL ANIMATIONS =====
  initializeAnimations() {
    // Intersection Observer for scroll animations
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px",
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible")
        }
      })
    }, observerOptions)

    // Add animation classes and observe elements
    document
      .querySelectorAll(
        ".section-title, .manifesto, .objective-box, .stat-item, .skill-category, .timeline-item, .project-card",
      )
      .forEach((el) => {
        el.classList.add("fade-in")
        observer.observe(el)
      })

    // Special animations for timeline items
    document.querySelectorAll(".timeline-item:nth-child(odd)").forEach((el) => {
      el.classList.add("slide-in-left")
      observer.observe(el)
    })

    document.querySelectorAll(".timeline-item:nth-child(even)").forEach((el) => {
      el.classList.add("slide-in-right")
      observer.observe(el)
    })
  }

  // ===== SKILL BARS ANIMATION =====
  animateSkillBars() {
    const skillBars = document.querySelectorAll(".skill-progress")

    const skillObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const skillBar = entry.target
            const width = skillBar.getAttribute("data-width")

            setTimeout(() => {
              skillBar.style.width = width + "%"
            }, 500)

            skillObserver.unobserve(skillBar)
          }
        })
      },
      { threshold: 0.5 },
    )

    skillBars.forEach((bar) => {
      skillObserver.observe(bar)
    })
  }

  // ===== COUNTER ANIMATION =====
  animateCounters() {
    const counters = document.querySelectorAll(".stat-number")

    const counterObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const counter = entry.target
            const target = Number.parseInt(counter.getAttribute("data-target"))

            this.animateCounter(counter, 0, target, 2000)
            counterObserver.unobserve(counter)
          }
        })
      },
      { threshold: 0.5 },
    )

    counters.forEach((counter) => {
      counterObserver.observe(counter)
    })
  }

  animateCounter(element, start, end, duration) {
    const startTime = performance.now()

    const updateCounter = (currentTime) => {
      const elapsed = currentTime - startTime
      const progress = Math.min(elapsed / duration, 1)

      // Easing function for smooth animation
      const easeOutCubic = 1 - Math.pow(1 - progress, 3)
      const current = Math.floor(start + (end - start) * easeOutCubic)

      element.textContent = current

      if (progress < 1) {
        requestAnimationFrame(updateCounter)
      } else {
        element.textContent = end
      }
    }

    requestAnimationFrame(updateCounter)
  }

  // ===== SCROLL EFFECTS =====
  setupScrollEffects() {
    // Parallax effect for hero background
    window.addEventListener("scroll", () => {
      const scrolled = window.pageYOffset
      const heroBackground = document.querySelector(".hero-background")

      if (heroBackground) {
        heroBackground.style.transform = `translateY(${scrolled * 0.5}px)`
      }
    })

    // Dynamic background color change
    const sections = document.querySelectorAll(".section")

    window.addEventListener("scroll", () => {
      sections.forEach((section) => {
        const rect = section.getBoundingClientRect()
        const isVisible = rect.top < window.innerHeight && rect.bottom > 0

        if (isVisible && section.classList.contains("about-section")) {
          document.body.style.background = "linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%)"
        } else if (isVisible && section.classList.contains("experience-section")) {
          document.body.style.background = "linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%)"
        }
      })
    })
  }

  // ===== UTILITY FUNCTIONS =====
  copyToClipboard(text) {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch((err) => {
        console.error("Erro ao copiar: ", err)
      })
    } else {
      // Fallback for older browsers
      const textArea = document.createElement("textarea")
      textArea.value = text
      document.body.appendChild(textArea)
      textArea.select()
      document.execCommand("copy")
      document.body.removeChild(textArea)
    }
  }

  showNotification(message) {
    // Create notification element
    const notification = document.createElement("div")
    notification.textContent = message
    notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #ff0000, #cc0000);
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            font-family: 'Orbitron', monospace;
            font-weight: 600;
            z-index: 10000;
            transform: translateX(100%);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 10px 30px rgba(255, 0, 0, 0.3);
        `

    document.body.appendChild(notification)

    // Animate in
    setTimeout(() => {
      notification.style.transform = "translateX(0)"
    }, 100)

    // Animate out and remove
    setTimeout(() => {
      notification.style.transform = "translateX(100%)"
      setTimeout(() => {
        document.body.removeChild(notification)
      }, 300)
    }, 3000)
  }

  // ===== PERFORMANCE OPTIMIZATION =====
  debounce(func, wait) {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout)
        func(...args)
      }
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
    }
  }

  throttle(func, limit) {
    let inThrottle
    return function () {
      const args = arguments
      
      if (!inThrottle) {
        func.apply(this, args)
        inThrottle = true
        setTimeout(() => (inThrottle = false), limit)
      }
    }
  }
}

// ===== ADDITIONAL INTERACTIVE FEATURES =====
class InteractiveFeatures {
  constructor() {
    this.setupKeyboardNavigation()
    this.setupMouseEffects()
    this.setupResponsiveFeatures()
  }

  setupKeyboardNavigation() {
    document.addEventListener("keydown", (e) => {
      // Navigate sections with arrow keys
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault()
        const sections = Array.from(document.querySelectorAll(".section, .hero-section"))
        const currentSection = this.getCurrentSection()
        const currentIndex = sections.findIndex((section) => section.id === currentSection)

        let nextIndex
        if (e.key === "ArrowDown") {
          nextIndex = Math.min(currentIndex + 1, sections.length - 1)
        } else {
          nextIndex = Math.max(currentIndex - 1, 0)
        }

        sections[nextIndex].scrollIntoView({ behavior: "smooth" })
      }
    })
  }

  getCurrentSection() {
    const sections = document.querySelectorAll(".section, .hero-section")
    let currentSection = ""

    sections.forEach((section) => {
      const rect = section.getBoundingClientRect()
      if (rect.top <= 100 && rect.bottom > 100) {
        currentSection = section.id
      }
    })

    return currentSection
  }

  setupMouseEffects() {
    // Cursor trail effect
    const cursor = document.createElement("div")
    cursor.className = "cursor-trail"
    cursor.style.cssText = `
            position: fixed;
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, rgba(255,0,0,0.8) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
            z-index: 9999;
            transition: transform 0.1s ease;
        `
    document.body.appendChild(cursor)

    document.addEventListener("mousemove", (e) => {
      cursor.style.left = e.clientX - 10 + "px"
      cursor.style.top = e.clientY - 10 + "px"
    })

    // Hide cursor trail on mobile
    if (window.innerWidth <= 768) {
      cursor.style.display = "none"
    }
  }

  setupResponsiveFeatures() {
    // Mobile menu toggle (if needed in future)
    const createMobileMenu = () => {
      if (window.innerWidth <= 768) {
        // Mobile-specific features can be added here
        console.log("Mobile view activated")
      }
    }

    window.addEventListener("resize", this.debounce(createMobileMenu, 250))
    createMobileMenu()
  }

  debounce(func, wait) {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout)
        func(...args)
      }
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
    }
  }
}

// ===== INITIALIZE APPLICATION =====
document.addEventListener("DOMContentLoaded", () => {
  // Initialize main application
  const app = new CurriculumApp()

  // Initialize interactive features
  const interactive = new InteractiveFeatures()

  // Add loading animation
  document.body.classList.add("loading")

  // Remove loading state after everything is loaded
  window.addEventListener("load", () => {
    setTimeout(() => {
      document.body.classList.remove("loading")
    }, 500)
  })

  // Console signature
  console.log(`
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║              JEREMIAS ANTÔNIO DA SILVA LIMEIRA              ║
    ║                    CURRÍCULO DIGITAL v1.0                   ║
    ║                                                              ║
    ║              "INEXORÁVEL: A presença que não                ║
    ║                     pode ser ignorada."                     ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
    
    Desenvolvido com HTML5, CSS3 e JavaScript Vanilla
    Design: Dark Mode Dominante | Animações Suaves | Responsivo
    `)
})

// ===== ERROR HANDLING =====
window.addEventListener("error", (e) => {
  console.error("Erro na aplicação:", e.error)
})

// ===== PERFORMANCE MONITORING =====
if ("performance" in window) {
  window.addEventListener("load", () => {
    setTimeout(() => {
      const perfData = performance.getEntriesByType("navigation")[0]
      console.log(`Tempo de carregamento: ${perfData.loadEventEnd - perfData.loadEventStart}ms`)
    }, 0)
  })
}
